# xml2yolo
label file converter: xml to yolo 

Python 3 script to convert VOC-style xml files to txt files required for training YOLO detectors.
Adapt the example to your needs.

Usage: 
$ python convert.py 



